﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp12;
using NUnit.Framework;

namespace ClassLibrary1
{
   
        [TestFixture]
        class AkashTests   
        {
            [Test]
            public void GetLength_input9_ExpectedLengthEquals9()
            {
                //Arrange
                int l = 9;
                int w = 7;
                Rectangle testRect = new Rectangle(l, w);

                //Act
                int length = testRect.GetLength();

                //Assert
                Assert.AreEqual(l, length);
            }
            [Test]
            public void GetWidth_input7_ExpectedWidthEquals7()
            {
                //Arrange
                int l = 6;
                int w = 7;
                Rectangle testRect = new Rectangle(l, w);

                //Act
                int width = testRect.GetWidth();

                //Assert
                Assert.AreEqual(w, width);
            }
            [Test]
            public void SetLength_input6_ExpectedLengthEquals6()
            {
                //Arrange
                int l = 6;
                int w = 2;
                Rectangle testRect = new Rectangle(l, w);

                //Act
                int actLength = testRect.SetLength(l);

                //Assert
                Assert.AreEqual(l, actLength);
            }
            [Test]
            public void SetWidth_input3_ExpectedWidthEquals3()
            {
                //Arrange
                int l = 4;
                int w = 3;
                Rectangle testRect = new Rectangle(l, w);

                //Act
                int actWidth = testRect.SetWidth(w);

                //Assert
                Assert.AreEqual(w, actWidth);
            }
            [Test]
            public void GetPerimeter_inputLength5_inputWidth2_ExpectedPerimeterEquals14()
            {
                //Arrange
                int l = 5;
                int w = 2;
                Rectangle testRect = new Rectangle(l, w);
                int expectedResult = 2 * (l + w);

                //Act
                int actPerimeter = testRect.GetPerimeter();

                //Assert
                Assert.AreEqual(expectedResult, actPerimeter);
            }
            [Test]
            public void GetArea_inputLength3_inputWidth4_ExpectedPerimeterEquals48()
            {
                //Arrange
                int l = 3;
                int w = 4;
                Rectangle testRect = new Rectangle(l, w);
                int expectedResult = l * w;

                //Act
                int actArea = testRect.GetArea();

                //Assert
                Assert.AreEqual(expectedResult, actArea);
            }
        }
    }