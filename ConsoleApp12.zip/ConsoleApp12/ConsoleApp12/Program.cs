﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace ConsoleApp12
{
    class Program
    {
        static void Main(string[] args)
        {
            int len = ValidattionOfInput("length");
            int wid = ValidattionOfInput("width");
            Console.WriteLine("Rectangle size is {0} * {1}", len, wid);
            Rectangle rect = new Rectangle(len, wid);

            do
            {
                int ui = Program.MenuValidation();
                switch (ui)
                {
                    case 1:
                        Console.WriteLine("Length of rectangle is : {0}", rect.GetLength());
                        break;
                    case 2:
                        Console.WriteLine("New Length is : {0}", rect.SetLength(ValidattionOfInput("length")));
                        break;
                    case 3:
                        Console.WriteLine("Width of rectangle is : {0}", rect.GetWidth());
                        break;
                    case 4:
                        Console.WriteLine("New Width is : {0}", rect.SetWidth(ValidattionOfInput("width")));
                        break;
                    case 5:
                        Console.WriteLine("Perimeter of rectangle is : {0}", rect.GetPerimeter());
                        break;
                    case 6:
                        Console.WriteLine("Area of rectangle is : {0}", rect.GetArea());
                        break;
                    case 7:
                        Environment.Exit(0);
                        break;
                }
            } while (true);
        }
        public static int MenuValidation()
        {
            int choice = 0;
            string str = String.Empty;
            bool flag = false;
            do
            {
                Console.WriteLine("1 = Check Rectangle Length");
                Console.WriteLine("2 = Change Rectangle Length");
                Console.WriteLine("3 = Check Rectangle Width");
                Console.WriteLine("4 = Change Rectangle Width");
                Console.WriteLine("5 = Check Rectangle Perimeter");
                Console.WriteLine("6 = Check Rectangle Area");
                Console.WriteLine("7 = Exit");
                Console.Write("Your selection? : ");

                str = Console.ReadLine();
                if (!int.TryParse(str, out choice))
                {
                    Console.WriteLine("Please enter correct value!");
                }
                else if (!((choice > 0) && (choice <= 7)))
                {
                    Console.WriteLine("Please enter correct value!");
                }
                else
                {
                    flag = true;
                }
            } while (flag==false);
            return choice;
        }
        public static int ValidattionOfInput(string rSide)
        {
            int no = 1;
            string str = String.Empty;
            bool flag = false;
            do
            {
                Console.Write("Provide {0} of rectangle(it should be >0) : ", rSide);
                str = Console.ReadLine();
                if (!int.TryParse(str, out no))
                {
                    Console.WriteLine("Please enter correct value!");
                }
                else if (!(no > 0))
                {
                    Console.WriteLine("Please enter correct value!");
                }
                else
                {
                    flag = true;
                }
            } while (flag==false);
            return no;
        }
    }
}
